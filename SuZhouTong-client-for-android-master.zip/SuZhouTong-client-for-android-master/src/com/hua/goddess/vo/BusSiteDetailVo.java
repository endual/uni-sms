package com.hua.goddess.vo;

public class BusSiteDetailVo {
	private String Guid;
	private String LName;
	private String LDirection;
	private String DBusCard;
	private String InTime;
	private String SName;
	private String Distince;

	public String getGuid() {
		return Guid;
	}

	public void setGuid(String guid) {
		Guid = guid;
	}

	public String getLName() {
		return LName;
	}

	public void setLName(String lName) {
		LName = lName;
	}

	public String getLDirection() {
		return LDirection;
	}

	public void setLDirection(String lDirection) {
		LDirection = lDirection;
	}

	public String getDBusCard() {
		return DBusCard;
	}

	public void setDBusCard(String dBusCard) {
		DBusCard = dBusCard;
	}

	public String getInTime() {
		return InTime;
	}

	public void setInTime(String inTime) {
		InTime = inTime;
	}

	public String getSName() {
		return SName;
	}

	public void setSName(String sName) {
		SName = sName;
	}

	public String getDistince() {
		return Distince;
	}

	public void setDistince(String distince) {
		Distince = distince;
	}

}
