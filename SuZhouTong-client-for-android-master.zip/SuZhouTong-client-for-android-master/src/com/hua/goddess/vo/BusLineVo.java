package com.hua.goddess.vo;

public class BusLineVo {
	private String Guid;
	private String LName;
	private String LDirection;
	public String getGuid() {
		return Guid;
	}
	public void setGuid(String guid) {
		Guid = guid;
	}
	public String getLName() {
		return LName;
	}
	public void setLName(String lName) {
		LName = lName;
	}
	public String getLDirection() {
		return LDirection;
	}
	public void setLDirection(String lDirection) {
		LDirection = lDirection;
	}
	
}
