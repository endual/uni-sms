package com.hua.goddess.vo;

public class StandInfoVo {
	private String SGuid;
	private String SName;
	private String SCode;
	private String BusInfo;
	private String InTime;
	private String OutTime;

	public String getSGuid() {
		return SGuid;
	}

	public void setSGuid(String sGuid) {
		SGuid = sGuid;
	}

	public String getSName() {
		return SName;
	}

	public void setSName(String sName) {
		SName = sName;
	}

	public String getSCode() {
		return SCode;
	}

	public void setSCode(String sCode) {
		SCode = sCode;
	}

	public String getBusInfo() {
		return BusInfo;
	}

	public void setBusInfo(String busInfo) {
		BusInfo = busInfo;
	}

	public String getInTime() {
		return InTime;
	}

	public void setInTime(String inTime) {
		InTime = inTime;
	}

	public String getOutTime() {
		return OutTime;
	}

	public void setOutTime(String outTime) {
		OutTime = outTime;
	}

}
