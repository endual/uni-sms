package com.hua.goddess.vo;


public class WeatherInfo {
	private String city;

	private String yujing;// 是否有预警，如果无，则为“暂无预警”
	private String alarmtext;

	private String warning;
	private String temp0;
	private String temp1;
	private String temp2;
	private String temp3;
	private String temp4;
	private String temp5;
	private String temp6;

	private String weather0;
	private String weather1;
	private String weather2;
	private String weather3;
	private String weather4;
	private String weather5;
	private String weather6;

	private String wind0;
	private String wind1;
	private String wind2;
	private String wind3;
	private String wind4;
	private String wind5;
	private String wind6;

	private String intime;
	private String tempNow;
	private String shidu;

	private String winNow;
	private String feelTemp;
	private String shiduNow;
	private String todaySun;
	private String tomorrowSun;
	private String AQIData;
	private String PM2Dot5Data;
	private String PM10Data;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getYujing() {
		return yujing;
	}

	public void setYujing(String yujing) {
		this.yujing = yujing;
	}

	public String getAlarmtext() {
		return alarmtext;
	}

	public void setAlarmtext(String alarmtext) {
		this.alarmtext = alarmtext;
	}

	public String getWarning() {
		return warning;
	}

	public void setWarning(String warning) {
		this.warning = warning;
	}

	public String getTemp0() {
		return temp0;
	}

	public void setTemp0(String temp0) {
		this.temp0 = temp0;
	}

	public String getTemp1() {
		return temp1;
	}

	public void setTemp1(String temp1) {
		this.temp1 = temp1;
	}

	public String getTemp2() {
		return temp2;
	}

	public void setTemp2(String temp2) {
		this.temp2 = temp2;
	}

	public String getTemp3() {
		return temp3;
	}

	public void setTemp3(String temp3) {
		this.temp3 = temp3;
	}

	public String getTemp4() {
		return temp4;
	}

	public void setTemp4(String temp4) {
		this.temp4 = temp4;
	}

	public String getTemp5() {
		return temp5;
	}

	public void setTemp5(String temp5) {
		this.temp5 = temp5;
	}

	public String getTemp6() {
		return temp6;
	}

	public void setTemp6(String temp6) {
		this.temp6 = temp6;
	}

	public String getWeather0() {
		return weather0;
	}

	public void setWeather0(String weather0) {
		this.weather0 = weather0;
	}

	public String getWeather1() {
		return weather1;
	}

	public void setWeather1(String weather1) {
		this.weather1 = weather1;
	}

	public String getWeather2() {
		return weather2;
	}

	public void setWeather2(String weather2) {
		this.weather2 = weather2;
	}

	public String getWeather3() {
		return weather3;
	}

	public void setWeather3(String weather3) {
		this.weather3 = weather3;
	}

	public String getWeather4() {
		return weather4;
	}

	public void setWeather4(String weather4) {
		this.weather4 = weather4;
	}

	public String getWeather5() {
		return weather5;
	}

	public void setWeather5(String weather5) {
		this.weather5 = weather5;
	}

	public String getWeather6() {
		return weather6;
	}

	public void setWeather6(String weather6) {
		this.weather6 = weather6;
	}

	public String getWind0() {
		return wind0;
	}

	public void setWind0(String wind0) {
		this.wind0 = wind0;
	}

	public String getWind1() {
		return wind1;
	}

	public void setWind1(String wind1) {
		this.wind1 = wind1;
	}

	public String getWind2() {
		return wind2;
	}

	public void setWind2(String wind2) {
		this.wind2 = wind2;
	}

	public String getWind3() {
		return wind3;
	}

	public void setWind3(String wind3) {
		this.wind3 = wind3;
	}

	public String getWind4() {
		return wind4;
	}

	public void setWind4(String wind4) {
		this.wind4 = wind4;
	}

	public String getWind5() {
		return wind5;
	}

	public void setWind5(String wind5) {
		this.wind5 = wind5;
	}

	public String getWind6() {
		return wind6;
	}

	public void setWind6(String wind6) {
		this.wind6 = wind6;
	}

	public String getIntime() {
		return intime;
	}

	public void setIntime(String intime) {
		this.intime = intime;
	}

	public String getTempNow() {
		return tempNow;
	}

	public void setTempNow(String tempNow) {
		this.tempNow = tempNow;
	}

	public String getShidu() {
		return shidu;
	}

	public void setShidu(String shidu) {
		this.shidu = shidu;
	}

	public String getWinNow() {
		return winNow;
	}

	public void setWinNow(String winNow) {
		this.winNow = winNow;
	}

	public String getFeelTemp() {
		return feelTemp;
	}

	public void setFeelTemp(String feelTemp) {
		this.feelTemp = feelTemp;
	}

	public String getShiduNow() {
		return shiduNow;
	}

	public void setShiduNow(String shiduNow) {
		this.shiduNow = shiduNow;
	}

	public String getTodaySun() {
		return todaySun;
	}

	public void setTodaySun(String todaySun) {
		this.todaySun = todaySun;
	}

	public String getTomorrowSun() {
		return tomorrowSun;
	}

	public void setTomorrowSun(String tomorrowSun) {
		this.tomorrowSun = tomorrowSun;
	}

	public String getAQIData() {
		return AQIData;
	}

	public void setAQIData(String aQIData) {
		AQIData = aQIData;
	}

	public String getPM2Dot5Data() {
		return PM2Dot5Data;
	}

	public void setPM2Dot5Data(String pM2Dot5Data) {
		PM2Dot5Data = pM2Dot5Data;
	}

	public String getPM10Data() {
		return PM10Data;
	}

	public void setPM10Data(String pM10Data) {
		PM10Data = pM10Data;
	}

	@Override
	public String toString() {
		return "AllWeather [city=" + city + ", yujing=" + yujing
				+ ", alarmtext=" + alarmtext + ", warning=" + warning
				+ ", temp0=" + temp0 + ", temp1=" + temp1 + ", temp2=" + temp2
				+ ", temp3=" + temp3 + ", temp4=" + temp4 + ", temp5=" + temp5
				+ ", temp6=" + temp6 + ", weather0=" + weather0 + ", weather1="
				+ weather1 + ", weather2=" + weather2 + ", weather3="
				+ weather3 + ", weather4=" + weather4 + ", weather5="
				+ weather5 + ", weather6=" + weather6 + ", wind0=" + wind0
				+ ", wind1=" + wind1 + ", wind2=" + wind2 + ", wind3=" + wind3
				+ ", wind4=" + wind4 + ", wind5=" + wind5 + ", wind6=" + wind6
				+ ", intime=" + intime + ", tempNow=" + tempNow + ", shidu="
				+ shidu + ", winNow=" + winNow + ", feelTemp=" + feelTemp
				+ ", shiduNow=" + shiduNow + ", todaySun=" + todaySun
				+ ", tomorrowSun=" + tomorrowSun + ", AQIData=" + AQIData
				+ ", PM2Dot5Data=" + PM2Dot5Data + ", PM10Data=" + PM10Data
				+ "]";
	}

}
